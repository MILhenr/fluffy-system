# Como colocar isso no ar (Railway)

Esta pasta já está pronta pra deploy: `index.html` (sua prancha/3D) + `package.json`
(diz ao Railway como servir o arquivo).

## Passo a passo

### 1. Criar uma conta no GitHub (se ainda não tiver)
https://github.com/signup

### 2. Criar um repositório novo
- No GitHub, clique em "New repository"
- Dê um nome, ex: `prancha-3d`
- Deixe público ou privado, tanto faz
- Não marque nenhuma opção extra (sem README, sem .gitignore)
- Clique em "Create repository"

### 3. Subir os arquivos desta pasta pro repositório
Mais fácil sem usar linha de comando:
- Na página do repositório recém-criado, clique em "uploading an existing file"
- Arraste os dois arquivos desta pasta (`index.html` e `package.json`)
- Clique em "Commit changes"

(Se preferir linha de comando, dentro desta pasta:)
```bash
git init
git add .
git commit -m "primeira versão"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/prancha-3d.git
git push -u origin main
```

### 4. Criar conta no Railway
https://railway.app — pode entrar direto com sua conta do GitHub

### 5. Criar o projeto
- No painel do Railway, clique em "New Project"
- Escolha "Deploy from GitHub repo"
- Selecione o repositório `prancha-3d` que você criou
- O Railway detecta o `package.json` sozinho e já faz o build

### 6. Pegar sua URL
- Depois do deploy terminar (barra de progresso fica verde), vá em
  **Settings → Networking → Generate Domain**
- Ele te dá uma URL tipo `prancha-3d-production.up.railway.app`
- Essa URL é sua, fixa, funciona de qualquer dispositivo, pra sempre
  (enquanto o projeto Railway existir)

## Atualizando depois
Sempre que eu (ou você) mudar o arquivo `index.html`, é só subir a versão nova
pro mesmo repositório GitHub (mesmo processo do passo 3) — o Railway detecta
a mudança e atualiza sozinho.

## Custos
O Railway tem um plano gratuito com limite de uso mensal (geralmente suficiente
pra um projeto pessoal como esse). Se passar do limite, cobra por uso — vale
checar o preço atual em https://railway.app/pricing antes de deixar rodando
por muito tempo.
